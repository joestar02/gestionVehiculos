"""
Test package for vehicle management system
"""
