class UploadError(Exception):
    """Raised when an uploaded file is invalid (type/size/etc)."""
    pass
