"""Database package"""
from .base import Base

__all__ = ['Base']
